import { supabaseAdmin } from "../lib/supabase";

export type UsuarioCreate = {
  uidauth?: string;
  nombre: string;
  apellido: string;
  email: string;
  telefono?: string | null;
  direccion?: string | null;
};

export type UsuarioUpdate = Partial<UsuarioCreate>;

export type UsuarioListQuery = {
  q?: string;
  estado?: "ACTIVO" | "INACTIVO" | "BLOQUEADO";
  page?: number;
  limit?: number;
};

function normalizeText(value?: string | null) {
  if (!value) return null;
  const v = String(value).trim();
  return v || null;
}

function normalizeNombre(value: string) {
  return String(value).trim().toUpperCase();
}

function normalizeEmail(value: string) {
  return String(value).trim().toLowerCase();
}

function parseUniqueError(msg: string) {
  if (msg.toLowerCase().includes("duplicate")) {
    return "Ya existe un usuario con ese email";
  }
  return msg;
}

export async function listarUsuarios(query: UsuarioListQuery) {
  const page = Math.max(1, Number(query.page ?? 1));
  const limit = Math.min(Math.max(Number(query.limit ?? 20), 1), 100);
  const from = (page - 1) * limit;
  const to = from + limit - 1;

  let q = supabaseAdmin
    .from("usuarios")
    .select("*", { count: "exact" })
    .range(from, to)
    .order("creado_en", { ascending: false });

  if (query.estado) q = q.eq("estado", query.estado);

  if (query.q) {
    const term = query.q.trim();
    q = q.or(
      `nombre.ilike.%${term}%,apellido.ilike.%${term}%,email.ilike.%${term}%`
    );
  }

  const { data, error, count } = await q;

  if (error) throw new Error(error.message);

  return {
    page,
    limit,
    total: count ?? 0,
    data: data ?? [],
  };
}

export async function obtenerUsuario(idusuario: string) {
  const { data, error } = await supabaseAdmin
    .from("usuarios")
    .select("*")
    .eq("idusuario", idusuario)
    .single();

  if (error) throw new Error("Usuario no encontrado");

  return data;
}

export async function crearUsuario(payload: UsuarioCreate) {
  const insert = {
    uidauth: normalizeText(payload.uidauth),
    nombre: normalizeNombre(payload.nombre),
    apellido: normalizeNombre(payload.apellido),
    email: normalizeEmail(payload.email),
    telefono: normalizeText(payload.telefono),
    direccion: normalizeText(payload.direccion),
  };

  if (!insert.nombre) throw new Error("nombre es obligatorio");
  if (!insert.apellido) throw new Error("apellido es obligatorio");
  if (!insert.email) throw new Error("email es obligatorio");

  const { data, error } = await supabaseAdmin
    .from("usuarios")
    .insert([insert])
    .select("*")
    .single();

  if (error) throw new Error(parseUniqueError(error.message));

  return data;
}



export async function obtenerAccesosDeUsuario(idusuario: string) {
  if (!idusuario) throw new Error("Falta idusuario");

  const usuario = await obtenerUsuario(idusuario);

  const { data: rolesData, error: rolesError } = await supabaseAdmin
    .from("usuario_rol")
    .select(`
      idusuariorol,
      estado,
      roles:roles (
        idrol,
        nombre,
        descripcion,
        estado
      )
    `)
    .eq("idusuario", idusuario)
    .eq("estado", true);

  if (rolesError) throw new Error(rolesError.message);

  const rolesActivos = (rolesData ?? [])
    .map((row: any) => row.roles)
    .filter((rol: any) => rol && rol.estado === true);

  const roleIds = rolesActivos.map((rol: any) => rol.idrol);

  let permisosActivos: any[] = [];

  if (roleIds.length > 0) {
    const { data: permisosData, error: permisosError } = await supabaseAdmin
      .from("rol_permiso")
      .select(`
        idrol,
        permisos:permisos (
          idpermiso,
          codigo,
          nombre,
          modulo,
          descripcion,
          estado
        )
      `)
      .in("idrol", roleIds);

    if (permisosError) throw new Error(permisosError.message);

    const mapa = new Map<string, any>();

    for (const row of permisosData ?? []) {
      const permiso = (row as any).permisos;
      if (!permiso || permiso.estado !== true) continue;

      if (!mapa.has(permiso.idpermiso)) {
        mapa.set(permiso.idpermiso, permiso);
      }
    }

    permisosActivos = Array.from(mapa.values());
  }

  return {
    usuario,
    roles: rolesActivos.map((rol: any) => ({
      idrol: rol.idrol,
      nombre: rol.nombre,
      descripcion: rol.descripcion,
    })),
    permisos: permisosActivos.map((permiso: any) => ({
      idpermiso: permiso.idpermiso,
      codigo: permiso.codigo,
      nombre: permiso.nombre,
      modulo: permiso.modulo,
      descripcion: permiso.descripcion,
    })),
  };
}



export async function actualizarUsuario(
  idusuario: string,
  payload: UsuarioUpdate
) {
  const update: any = {};

  if (payload.nombre !== undefined)
    update.nombre = normalizeNombre(payload.nombre);

  if (payload.apellido !== undefined)
    update.apellido = normalizeNombre(payload.apellido);

  if (payload.email !== undefined)
    update.email = normalizeEmail(payload.email);

  if (payload.telefono !== undefined)
    update.telefono = normalizeText(payload.telefono);

  if (payload.direccion !== undefined)
    update.direccion = normalizeText(payload.direccion);

  if (Object.keys(update).length === 0)
    throw new Error("No hay datos para actualizar");

  const { data, error } = await supabaseAdmin
    .from("usuarios")
    .update(update)
    .eq("idusuario", idusuario)
    .select("*")
    .single();

  if (error) throw new Error(parseUniqueError(error.message));

  return data;
}

export async function cambiarEstadoUsuario(
  idusuario: string,
  estado: "ACTIVO" | "INACTIVO" | "BLOQUEADO"
) {
  const { data, error } = await supabaseAdmin
    .from("usuarios")
    .update({ estado })
    .eq("idusuario", idusuario)
    .select("*")
    .single();

  if (error) throw new Error(error.message);

  return data;
}

export async function eliminarUsuario(idusuario: string) {
  const { error } = await supabaseAdmin
    .from("usuarios")
    .delete()
    .eq("idusuario", idusuario);

  if (error) throw new Error(error.message);

  return { ok: true };
}